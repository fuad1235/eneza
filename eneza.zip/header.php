<!doctype html>  
<html lang="en">  
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Eneza</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">  
<![if !IE]>
<link rel="icon" href="_images/fungicon.png" type="image/png" />
<![endif]>
<link rel="shortcut icon" href="_images/fungicon.png" type="image/icon" />
<link href="_css/style.css" rel="stylesheet" type="text/css"/>
</head>

