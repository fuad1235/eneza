<body>
<div id="header"></div>
<?php
echo '<br>';
echo '<div class="subbodys">';
echo '<h5> <a href="index.php" >Home</a> </h5>';
echo '</div>';
?> 	
<br><br><div><span style="color:#ff8000">Sorry try again next time</span></div><br><br><br>